import mysql from "mysql2/promise";

var create_connection=mysql.createPool({
    host:'localhost',
    user:'root',
    password:"",
    database:"scoreboard"

})
// create_connection.connect((err)=>{
//     if(err){
//         console.log("error : not connected")
//     }
//     else{
//         console.log("DB connected successfully .")
//         }
// })

export default create_connection;