import connect from '../connection/db.js';

const login = async (req, res) => {
  try {
    const { username, password } = req.body;
    console.log("Received username:", username);

    // Query database using async/await
    const [result] = await connect.execute('SELECT * FROM user WHERE username = ?', [username]);

    if (result.length === 0) {
      return res.status(404).json({ success: false, message: "User not found" });
    }

    if (result[0].password !== password) {
      return res.status(401).json({ success: false, message: "Invalid credentials" });
    }

    return res.json({
      success: true,
      message: "Login successful",
      user: { user_id: result[0].id, username: result[0].username, company: result[0].company },
       
    });

  } catch (error) {
    console.error("Server error:", error);
    return res.status(500).json({ success: false, message: "Internal Server Error" });
  }
};



export default login;
