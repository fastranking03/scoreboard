
import connect from '../connection/db.js'
export const sparta_add_employee = async (req, res) => {
  try {
    const {user_id, user_name, emp_name, score } = req.body;

    const [insertResult] = await connect.execute(
      "INSERT INTO score_data (user_id, user_name, emp_name, score, created_at) VALUES (?, ?, ?, ?, NOW());",
      [user_id, user_name, emp_name, score]
    );

    res.status(200).send({
      success: true,
      message: "Employee added successfully",
      data: insertResult
    });
   
  }catch (error) {
    res.status(500).send({ success: false, message: "Error adding user" });
  }
};

export const update_score = async (req, res) => {
  try {
    const { id } = req.params;
    const { score } = req.body;

    if (!id || score === undefined) {
      return res.status(400).json({
        success: false,
        message: "ID and score are required",
      });
    }

    const query = "UPDATE score_data SET score = ? WHERE id = ?";
    const values = [score, id];

    const [result] = await connect.execute(query, values);

    if (result.affectedRows === 0) {
      return res.status(404).json({
        success: false,
        message: "No record found with the given ID",
      });
    }

    res.status(200).json({
      success: true,
      message: "Score updated successfully",
    });
  } catch (error) {
    console.error("Error updating score:", error);
    res.status(500).json({
      success: false,
      message: "Error updating score",
    });
  }
};

export const displayEmp = async (req, res) => {
  try {
    const { username } = req.params;
   

    if (!username) {
      return res.status(400).json({
        success: false,
        message: "User ID is required",
      });
    }

    // Execute query correctly
    const result = await connect.execute(
      "SELECT * FROM score_data WHERE user_name = ? ORDER BY created_at DESC;",
      [username]
    );

    // `result` is an array where the first element contains rows
    const [rows] = result;

    if (!rows || rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: "No score data found for this user",
      });
    }

    res.status(200).json({
      success: true,
      message: "Score data retrieved successfully",
      data: rows,
    });

  } catch (error) {
    console.error("Database Error:", error);
    res.status(500).json({
      success: false,
      message: "Error retrieving score data",
      error: error.message,
    });
  }
};

 
export const delete_employee = async (req, res) => {
  try {
    const { id } = req.params;

    if (!id) {
      return res.status(400).json({
        success: false,
        message: "Employee ID is required",
      });
    }

    const query = "DELETE FROM score_data WHERE id = ?";
    const [result] = await connect.execute(query, [id]);

    if (result.affectedRows === 0) {
      return res.status(404).json({
        success: false,
        message: "No employee found with this ID",
      });
    }

    res.status(200).json({
      success: true,
      message: "Employee deleted successfully",
    });
  } catch (error) {
    console.error("Error deleting employee:", error);
    res.status(500).json({
      success: false,
      message: "Error deleting employee",
    });
  }
};
