import express from 'express'
import { delete_employee, sparta_add_employee, update_score, displayEmp} from '../controllers/scoreController.js';
const router = express.Router();

router.delete('/delete_emp/:id',delete_employee)
router.post("/update_sp/:id",update_score)
router.post("/create_employee_sp", sparta_add_employee)
router.get('/emp-list/:username', displayEmp)

 export default router; 