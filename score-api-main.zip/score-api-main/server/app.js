import express from "express";
const app = express();
const port = 8000;
import userRoutes from "./routes/userRoutes.js";
import scoreRoute from './routes/scoreRoute.js'
 
import cors from "cors"

app.use(cors())
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use("/", userRoutes);
app.use('/',scoreRoute);
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
