import {BrowserRouter, Route, Routes} from "react-router-dom"
import Home from "./pages/Home";
import Login from "./pages/Login";
import AdminHome from "./pages/AdminHome";

function App() {
  return (
     
      <BrowserRouter>
        <Routes>
           <Route element={<Home/>} index />
           <Route element={<Login/>} path="/admin-login" />
           <Route element={<AdminHome/>} path="/employee-list" />
        </Routes>
      </BrowserRouter>
     
  );
}

export default App;
