import axios from 'axios';
import React, { useEffect, useRef, useState } from 'react'
import Confetti from "react-confetti";
const Veerepairs = () => {
    const [data, setData] = useState([]);
    const [showConfetti, setShowConfetti] = useState(false);
    const confettiRef = useRef(null);
    const fetchEmployees = async () => {
        try {
            const res = await axios.get("http://localhost:8000/emp-list/veerepairs");
            let sortedData = res.data.data.sort((a, b) => b.score - a.score);
            
            if (sortedData.length > 1) {
                const topPerformer = sortedData[0];
                const otherPerformers = sortedData.slice(1).sort((a, b) => a.emp_name.localeCompare(b.emp_name));
                
                sortedData = [topPerformer, ...otherPerformers];
            }
            
            setData(sortedData.slice(0, 5));
            setShowConfetti(true);
        } catch (e) {
            console.error("Error fetching data:", e);
        }
    };
    

    useEffect(() => {
        fetchEmployees();
    }, []);
    if (data.length === 0) {
        return <p className="text-white text-center mt-10">Loading...</p>;
    }

    const topPerformer = data[0];
    const otherPerformers = data.slice(1);
  return (
    <section className='h-screen bg-black/80 bg-fastranking h-full'>
    <div className='flex items-center justify-between p-2 px-5'>
        <div className='flex gap-6 items-center'>
            <img src='https://res.cloudinary.com/dj7wogsju/image/upload/v1739355150/Vector_qor1hz.png' className='w-[40px]' alt='' />
            <h3 className='text-white text-[24px] font-[600]'>Top Five Performer Of The Month</h3>
        </div>
        <div>
            <img src='https://res.cloudinary.com/dj7wogsju/image/upload/v1739370958/download_kwbdqt.png' className='w-[220px] h-[80px]' alt='' />
        </div>
    </div>
    <div className='mt-30'>
        <div className='lg:w-[1080px] mx-auto '>
            <div className='p-5 px-10 relative score-row '>
                <div className='absolute left-[-30px] top-10'>
                    <span className='bg-[#E6BB24;] w-[70px] h-[70px] flex items-center justify-center text-[36px] font-[600]'>1</span>
                </div>
                <div className='absolute bottom-0'>
                    <img src='https://res.cloudinary.com/dj7wogsju/image/upload/v1739354613/ttrrpphhuu_2_m6ikkb.png' className='w-[300px]' alt='' />
                </div>
                <div className='flex items-center justify-between  pl-100'>
                    <div className='relative'>
                       {showConfetti && (
                            <Confetti
                                width={confettiRef.current?.offsetWidth || 300} 
                                height={confettiRef.current?.offsetHeight || 100} 
                                numberOfPieces={30} 
                                gravity={0.2} 
                                style={{
                                    position: "absolute",
                                    top: "-30px",
                                    left: "50%",
                                    transform: "translateX(-50%)",
                                    pointerEvents: "none",
                                  }}
                            />
                            )}
                        <h2 className='text-[60px] font-[600] text-white'  style={{ textShadow: "-5px 2px #ca8d34" }}>{topPerformer.emp_name}</h2>
                    </div>
                    <div className='relative'>
                        <img src='https://res.cloudinary.com/dj7wogsju/image/upload/v1739354611/Group_1000004799_whgaia.png' className='w-[300px]' alt='' />
                        <div className='absolute top-0 left-[118px]'>
                            <h4 className='text-[70px] text-white font-[900] tracking-[7px] text-animated'>{topPerformer.score}</h4>
                        </div>
                    </div>
                </div>
            </div>
            <div className='mt-8'>
                <div className='grid grid-cols-2 gap-x-15 gap-y-6 items-center'>
                  
                {otherPerformers.map((emp, index) => (
                                <div key={emp.id} className="grid-card relative p-5 pl-20 px-10 border-[2px] border-[#280466]">
                                    <div>
                                        <div className="absolute left-[-30px] top-[20px]">
                                            <span className="grid-card-num w-[60px] h-[60px] flex items-center justify-center text-[32px] font-[600] text-white">
                                                {index + 2}
                                            </span>
                                        </div>
                                        <div className="flex justify-between items-center">
                                            <div>
                                                <h2 className="text-white text-[36px] font-[700]">
                                                    {emp.emp_name}
                                                </h2>
                                            </div>
                                            <div className="flex items-center gap-2">
                                                <span>
                                                    <img
                                                        src="https://res.cloudinary.com/dj7wogsju/image/upload/v1739354611/Polygon_3_dlgsjn.png"
                                                        className="w-[28px] mt-[12px]"
                                                        alt="icon"
                                                    />
                                                </span>
                                                <span className="text-[50px] text-white font-[700]">
                                                    {emp.score}
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            ))}
                  </div>
            </div>
        </div>
    </div>

</section>
  )
}

export default Veerepairs
