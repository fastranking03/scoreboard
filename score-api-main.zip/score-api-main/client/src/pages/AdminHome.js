import React, { useEffect, useState } from 'react'
import { useAuth } from './context/authContext'
import axios from 'axios';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
const AdminHome = () => {
    const [auth] = useAuth();
     const [isOpen, setIsOpen] = useState(false);

    // Add Employee
    const [emp_name, setEmployee] = useState("");
    const [score, setScore] = useState("")
    const user_id = auth?.user?.user_id
    const user_name = auth?.user?.username
    const handleSubmitEmployee = async (e) => {
        e.preventDefault();
        try {
            const response = await axios.post(`http://localhost:8000/create_employee_sp`, {
                user_id,
                user_name,
                emp_name,
                score,
            });

            if (response.data.success) {
                toast.success("Employee added successfully!");
                setIsOpen(false);
                setEmployee("");
                setScore(0);
                disEmp()
            }
        } catch (error) {
            console.error("Error adding employee:", error);
            toast.error("Failed to add employee.");
        }
    };

    // Display Data
    const [data, setData] = useState([]);
    const disEmp = async () => {
        try {
            const res = await axios.get(`http://localhost:8000/emp-list/${auth?.user?.username}`)
            console.log(res.data.data);
            setData(res.data.data)
        } catch (e) {
            console.log(e)
        }
    }
    useEffect(() => {
        disEmp();
    }, [auth]);

    // Update Score
    const updtaeEmployeeScore = (id, score) => {
        axios.post(`http://localhost:8000/update_sp/${id}`, { "score": score }).then((response) => console.log(id)).catch((err) => console.log(err))
        disEmp();
    }

    // Delete Emp
    const handleDelete = async (id) => {
        if (!window.confirm("Are you sure you want to delete this employee?")) return;

        try {
            const response = await axios.delete(`http://localhost:8000/delete_emp/${id}`);
            if (response.data.success) {
                toast.success("Employee deleted successfully!");
                setData((prevEmployees) => prevEmployees.filter(emp => emp.id !== id));
            } else {
                toast.error("Failed to delete employee.");
            }
        } catch (error) {
            console.error("Error deleting employee:", error);
            toast.error("Error deleting employee.");
        }
    };
    return (
        <>
            <ToastContainer style={{ zIndex: "999999" }}
                position="top-center"
                autoClose={1000}
                hideProgressBar={false}
                newestOnTop={false}
                closeOnClick
                rtl={false}
                pauseOnFocusLoss
                draggable
                pauseOnHover
                theme="light"
            />
            <div
                className="min-h-screen overflow-hidden  bg-black"
                style={{
                    backgroundImage: 'url("https://res.cloudinary.com/dj7wogsju/image/upload/v1739354444/image_1_yptl8t.png")',
                    backgroundRepeat: "no-repeat",
                    backgroundSize: "150%",
                    backgroundPosition: "right center"
                }}
            >
                <div className="w-full">
                    <div className="bg-transparent backdrop-blur-xl border-b p-4 flex justify-between items-center h-20">
                        <div className="w-1/4 pl-10">
                        <a href="/">
                        <img
                            src={
                            auth?.user?.username === "fastranking"
                                ? "https://res.cloudinary.com/dj7wogsju/image/upload/v1739355149/Group_1000004697_wwd2l9.svg"
                                : auth?.user?.username === "sparta"
                                ? "https://scoreboard.fastranking.tech/static/media/Sparta%20logo%20white.7e19ccbf583d1354aaa5d78a28c835a4.svg"
                                : auth?.user?.username === "veerepairs"
                                ? "https://res.cloudinary.com/dj7wogsju/image/upload/v1739370958/download_kwbdqt.png"
                                : "https://default-logo-url.com/logo.svg" // Default if username doesn't match
                            }
                            alt="User Logo"
                            width="160px"
                        />
                        </a>
                            
                        </div>
                        <div className="w-2/4 flex justify-center items-center">
                            <span className="cursor-pointer">
                                <svg
                                    xmlns="http://www.w3.org/2000/svg"
                                    width="1.8em"
                                    height="1.8em"
                                    viewBox="0 0 24 24"
                                >
                                    <path fill="black" d="M18 12a6 6 0 1 1-12 0a6 6 0 0 1 12 0" />
                                    <path
                                        fill="black"
                                        fillRule="evenodd"
                                        d="M12 1.25a.75.75 0 0 1 .75.75v1a.75.75 0 0 1-1.5 0V2a.75.75 0 0 1 .75-.75M4.399 4.399a.75.75 0 0 1 1.06 0l.393.392a.75.75 0 0 1-1.06 1.061l-.393-.393a.75.75 0 0 1 0-1.06m15.202 0a.75.75 0 0 1 0 1.06l-.393.393a.75.75 0 0 1-1.06-1.06l.393-.393a.75.75 0 0 1 1.06 0M1.25 12a.75.75 0 0 1 .75-.75h1a.75.75 0 0 1 0 1.5H2a.75.75 0 0 1-.75-.75m19 0a.75.75 0 0 1 .75-.75h1a.75.75 0 0 1 0 1.5h-1a.75.75 0 0 1-.75-.75m-2.102 6.148a.75.75 0 0 1 1.06 0l.393.393a.75.75 0 1 1-1.06 1.06l-.393-.393a.75.75 0 0 1 0-1.06m-12.296 0a.75.75 0 0 1 0 1.06l-.393.393a.75.75 0 1 1-1.06-1.06l.392-.393a.75.75 0 0 1 1.061 0M12 20.25a.75.75 0 0 1 .75.75v1a.75.75 0 0 1-1.5 0v-1a.75.75 0 0 1 .75-.75"
                                        clipRule="evenodd"
                                    />
                                </svg>
                            </span>
                        </div>
                        <div className="w-1/4 h-12 max-h-12 flex justify-end items-center text-white text-3xl">
                        Performer Of The Month
                        </div>
                    </div>
                    <div className="relative w-4/5 m-auto min-h-96 shadow-2xl rounded-2xl border-2 p-8 pt-6 mt-20 mb-10 bg-white shadow-gray-50 border-purple-400">
                        <div className="w-full bg-red-600">
                            <button className="bg-purple-600 text-white absolute -top-14 right-0 rounded-full  p-2 px-6 cursor-pointer" onClick={() => setIsOpen(true)}>
                                Add New Employee
                            </button>

                        </div>
                        <div className="w-full p-2 px-4 pt-0 grid grid-cols-3 mb-4">
                            <div className="p-2 text-base font-semibold">Agent Name</div>
                            <div className="p-2 text-base font-semibold text-center">
                                Current Score
                            </div>
                            <div className="p-2 text-base font-semibold text-end">New Score</div>
                        </div>
                        {data.length > 0 ? (
                            data.map((emp, index) => (
                                <div className="w-full p-1 border shadow-xl rounded-xl mb-4 grid grid-cols-3 items-center shadow-gray-100" key={index}>
                                    <div className="p-2 text-base pl-4">{emp.emp_name}</div>
                                    <div className="p-2 text-base text-center">{emp.score}</div>
                                    <div className="flex justify-end">
                                        <div className="text-base text-end">
                                            <input
                                                className="w-20 text-base p-0.5 px-4 text-center rounded-full mr-2 bg-gray-200"
                                                type="number"
                                                min={0}
                                                defaultValue={emp.score}
                                                onChange={(e) => {
                                                    const newScore = e.target.value;
                                                    updtaeEmployeeScore(emp.id, newScore)

                                                }}
                                            />
                                        </div>
                                        <button onClick={() => handleDelete(emp.id)} className="h-8 w-8 inline-flex justify-center items-center hover:bg-gray-800 cursor-pointer bg-gray-700 rounded-full">
                                            <svg
                                                xmlns="http://www.w3.org/2000/svg"
                                                width="1.2em"
                                                height="1.2em"
                                                viewBox="0 0 24 24"
                                            >
                                                <path
                                                    fill="#fff"
                                                    d="M7 21q-.825 0-1.412-.587T5 19V6H4V4h5V3h6v1h5v2h-1v13q0 .825-.587 1.413T17 21zm2-4h2V8H9zm4 0h2V8h-2z"
                                                />
                                            </svg>
                                        </button>
                                    </div>
                                </div>
                            ))
                        ) : (

                            <div colSpan="3" className="px-6 py-4 text-center text-gray-500">No employees found</div>

                        )}
                    </div>
                </div>
            </div>

            {/* Popup Form */}
            {isOpen && (
                <div
                    className="h-screen w-screen fixed flex justify-center items-center top-0 left-0 bg-black/90 bg-opacity-50"
                    onClick={() => setIsOpen(false)} // Close when clicking outside the form
                >
                    <form onSubmit={handleSubmitEmployee}
                        className="h-80 w-96 p-8 bg-white rounded-2xl"
                        onClick={(e) => e.stopPropagation()}
                    >
                        <h1 className="text-xl mb-5 text-center mt-5">Fast Ranking</h1>
                        <input
                            className="w-full border rounded-full p-2 px-5"
                            type="text" name='emp_name'
                            onChange={(e) => setEmployee(e.target.value)}
                            placeholder="Employee Name"
                        />
                        <input
                            className="w-full border rounded-full mt-3 p-2 px-5"
                            type="number"
                            placeholder="Current Sales"
                            name="score"
                            onChange={(e) => setScore(e.target.value)}
                            value={score}
                        />
                        <input type="hidden" name="user_id" value={auth?.user?.user_id} />
                        <input type="hidden" name="user_name" value={auth?.user?.username} />

                        <div className="flex mt-5">
                            <input
                                className="cursor-pointer w-full p-2 px-5 mr-4 bg-gray-100 rounded-full"
                                type="reset"
                                value="Cancel"
                                onClick={() => setIsOpen(false)}
                            />
                            <button
                                className="cursor-pointer w-full p-2 px-5 bg-green-500 text-white rounded-full"
                                type="submit"
                            > Submit</button>
                        </div>
                    </form>
                </div>
            )}
        </>
    )
}

export default AdminHome