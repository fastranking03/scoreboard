import React, { useEffect, useState } from 'react';
import SpartaComp from './conponents/SpartaComp';
import FastrankingCompo from './conponents/FastrankingCompo';
import Veerepairs from './conponents/Veerepairs';
 
const Home = () => {
    const [index, setIndex] = useState(0);
    const components = [<SpartaComp />, <FastrankingCompo />, <Veerepairs />];
  
    useEffect(() => {
      const interval = setInterval(() => {
        setIndex((prevIndex) => (prevIndex + 1) % components.length);
      }, 5000); // Change every 2 seconds
  
      return () => clearInterval(interval); // Cleanup interval on unmount
    }, []);
  
    return (
      <div className="slider-container">
        <div className="slider" style={{ transform: `translateX(-${index * 100}%)` }}>
          {components.map((Component, i) => (
            <div key={i} className="slide">
              {Component}
            </div>
          ))}
        </div>
      </div>
    );
  };
  
  export default Home;
