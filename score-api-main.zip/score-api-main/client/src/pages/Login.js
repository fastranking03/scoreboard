import { useState } from "react";
import { useAuth } from "./context/authContext";
import axios from "axios";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { useNavigate } from 'react-router-dom';
const Login = () => {
    const [username, setUserName] = useState("");
    const [password, setPassword] = useState("");
    const [error, setError] = useState("");
    const [auth, setAuth] = useAuth();
    const navigate = useNavigate();
    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!username || !password) {
            setError("Both fields are required!");
            return;
        }
        try {
            const res = await axios.post(`http://localhost:8000/admin-login`, { username, password });

            if (res && res.data.success) {
                toast.success(res.data && res.data.message);
                setAuth({
                    ...auth,
                    user: res.data.user
                });

                localStorage.setItem('auth', JSON.stringify(res.data))
                if (res.data.user) {
                    navigate("/employee-list")
                } else {

                }

            } else {
                toast.error(res.data.message);
            }
        }
        catch (error) {
            toast.error("Something Went Wrong");
        }
    };

    return (
        <>
            <ToastContainer style={{ zIndex: "999999" }}
                position="top-center"
                autoClose={2000}
                hideProgressBar={false}
                newestOnTop={false}
                closeOnClick
                rtl={false}
                pauseOnFocusLoss
                draggable
                pauseOnHover
                theme="light"
            />

            <div className="flex min-h-screen items-center justify-center bg-gray-900 p-4">
                <div className="relative w-full max-w-md p-8 bg-gray-800/60 backdrop-blur-md shadow-xl rounded-2xl border border-gray-700 transition-all duration-300">
                    {/* Animated Glow */}
                    <div className="absolute inset-0 bg-gradient-to-r from-blue-500 to-purple-600 blur-2xl opacity-20 rounded-2xl"></div>

                    {/* Form Header */}
                    <h2 className="text-3xl font-bold text-center text-white mb-6">Login</h2>

                    {error && <p className="text-red-400 text-sm text-center mb-3">{error}</p>}

                    {/* Form Fields */}
                    <form onSubmit={handleSubmit} className="space-y-4 relative z-10">
                        <div className="relative">
                            <label className="block text-sm font-medium text-gray-300">User Name</label>
                            <input
                                type="text"
                                className="mt-1 block w-full px-4 py-2 bg-gray-700 text-white border border-gray-600 rounded-lg focus:ring-1 focus:ring-blue-500 focus:border-blue-500 outline-none transition duration-300"
                                placeholder="Enter your User Name"
                                value={username} name="username"
                                onChange={(e) => setUserName(e.target.value)}
                            />
                        </div>

                        <div className="relative">
                            <label className="block text-sm font-medium text-gray-300">Password</label>
                            <input
                                type="password" name="password"
                                className="mt-1 block w-full px-4 py-2 bg-gray-700 text-white border border-gray-600 rounded-lg focus:ring-1 focus:ring-blue-500 focus:border-blue-500 outline-none transition duration-300"
                                placeholder="Enter your password"
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                            />
                        </div>

                        {/* Submit Button */}
                        <button
                            type="submit"
                            className="w-full bg-[#130062] text-white font-semibold py-2 rounded-lg hover:bg-[#261FE5] transition-all duration-300 transform "
                        >
                            Login
                        </button>
                    </form>

                </div>
            </div>
        </>
    );
};

export default Login;
